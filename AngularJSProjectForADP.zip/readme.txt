// Albert Xie
// Apr 10, 2016

angular.js
characters.json
main_backn.jpg
myscript.js
mystyle.css
index.html

