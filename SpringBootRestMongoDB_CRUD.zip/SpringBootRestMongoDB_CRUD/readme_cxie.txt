// readme_cxie.txt, 01/30/2016, 04/24/2016, 09/05/2016

====== Spring Boot, Restful Web Svc, JSON, JUnit, MongoDB ======

Remarks:

     1. Unit Test   
     2. Do not need server running
     3. Need MongoDB running
     
0. http://www.javabeat.net/restful-springboot-mongodb/
1. Make sure MongoDB is running
2. Use Eclipse (J2EE) to open the project file pom.xml
3. Run "Application.java" as Application
4. Run "BookControllerTest.java" as JUnit Test

-------------- In Eclipse ----------------------

Do not need to start server
Just run "BookControllerTest.java" as JUnit Test

-------------- Command Line --------------------

c:\...> mvn clean install

In testUpdateBookDetails() .........
Book saved successfully: ID=58df21eca75b9e5629017f71,Name=Book1,isbn=ISBN1,author=Author1,pages=200

Update Book 58df21eca75b9e5629017f71 successfully
After update, Book: ID=58df21eca75b9e5629017f71,Name=Book2,isbn=ISBN2,author=Author2,pages=202
End testUpdateBookDetails() .........

In testCreateBookApi() .........
Created Book with 200 pages successfully
bookId: 58df21eca75b9e5629017f72
Got Book 58df21eca75b9e5629017f72 and its details successfully
Book 58df21eca75b9e5629017f72 deleted successfully
End testCreateBookApi() .........

In testGetAllBooksApi() .........
Got 2 books successfully
End testGetAllBooksApi() .........

In testGetBookDetailsApi() .........
Book details: ID=58df21eca75b9e5629017f75,Name=Book1,isbn=ISBN1,author=Author Tongyu,pages=201
End testGetBookDetailsApi() .........

In testDeleteBookApi() .........
End testDeleteBookApi() .........

Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.598 sec 

Results :

Tests run: 5, Failures: 0, Errors: 0, Skipped: 0
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
[INFO] Total time: 7.371 s
[INFO] Finished at: 2017-03-31T23:43:41-04:00
[INFO] Final Memory: 28M/299M