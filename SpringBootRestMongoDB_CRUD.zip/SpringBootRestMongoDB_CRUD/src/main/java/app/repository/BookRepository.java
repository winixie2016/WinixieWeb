package app.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import app.model.Book;

public interface BookRepository extends MongoRepository<Book, String>{
	// http://docs.spring.io/spring-data/mongodb/docs/current/api/org/springframework/data/mongodb/repository/MongoRepository.html 
    // save(Iterable<S> entites) 
	// insert(S entity)
	// insert(Iterable<S> entities)
	// findAll(Sort sort)
	// findAll(Example<S> example, Sort sort)
	// findAll(Example<S> example) 
	// findAll() 
	// count, delete, delete, delete, deleteAll, exists, findAll, findOne, save
	// count, exists, findAll, findOne
}
