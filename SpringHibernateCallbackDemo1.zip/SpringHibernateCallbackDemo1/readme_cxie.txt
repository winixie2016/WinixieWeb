// readme_cxie.txt
// 01/03/2017

http://www.java2s.com/Code/Java/Hibernate/HibernateSpringHibernateCallbackDemo.htm

It uses in-memory database hsqldb.

It shows:

    1. HibernateCallback.doInHibernate
    
    