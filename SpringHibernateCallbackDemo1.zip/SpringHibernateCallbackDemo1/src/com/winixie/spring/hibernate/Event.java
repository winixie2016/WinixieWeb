package com.winixie.spring.hibernate;

import java.io.Serializable;
import java.util.Date;

public class Event implements Serializable {
	
	private final static long serialVersionUID = 101010L;
	
    private Long id;
    private int duration;
    private String name;
    private Date startDate;

    public Event() {

    }

    public Event(String name) {
        this.name = name;
    }

    public Event(String name, int howLong, Date date) {
        this.name = name;
        duration = howLong;
        startDate = date;
    }
    
    /**
     * @hibernate.id generator-class="native" column="uid"
     * @return
     */
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    /**
     * @hibernate.property column="name"
     * @return
     */
    public String getName() { return name; }
    public void setName(String name) { this.name = name;   }

    /**
     * @hibernate.property column="start_date"
     * @return
     */
    public Date getStartDate() { return startDate; }
    public void setStartDate(Date startDate) { this.startDate = startDate; }

    /**
     * @hibernate.property column="duration"
     * @return
     */
    public int getDuration() { return duration; }    
    public void setDuration(int duration) { this.duration = duration; }
    
    @Override
    public String toString() {
    	
    	return ("id="+id+",name="+name+",duration="+duration+",startDate="+startDate);
    }
}
