package com.winixie.spring.hibernate;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

public class Main {

	public static void main(String[] args) {
		HibernateUtil.setup("create table EVENTS ( uid int, name VARCHAR, start_Date date, duration int);");
		
		// hibernate code start
        HibernateFactory.buildSessionFactory();
        SessionFactory sessionFactory= HibernateFactory.getSessionFactory();
        HibernateTemplate template= new HibernateTemplate(sessionFactory);

        for (int i = 1; i < 11; i++) {
        	
        	Event event = new Event("Event " + i, 1000*i , (new java.util.Date()));
	      
	        template.save(event);
        }

        List<Event> results = template.executeFind(new HibernateCallback() {
            public Object doInHibernate(Session session) throws HibernateException, SQLException {
                Query query = session.createQuery("from Event");
                query.setMaxResults(2);
                return query.list();
            }
        });

        int count = results.size();
        
        for (int ctr = 0; ctr < count; ctr++)
             System.out.println(results.get(ctr));       
        
        HibernateUtil.checkData("select uid, name from events");        

        HibernateFactory.closeFactory();
        
		// hibernate code end
	}	
}