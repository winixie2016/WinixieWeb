// readme_cxie.txt
// 02/04/2017

http://www.javarticles.com/2015/04/spring-hibernatetempate-example.html
   (Apr 16, 2015)
   
All the 4 programs run successfully!

It shows:

    1. HibernateCallback.doInHibernate
    2. HibernateTemplate
    3. SessionFactory in Hibernate
    4. Table join 
    5. HibernateTemplate().findByNamedParam(...)
    
Setup:
    
    In MySQL, execute statements in setup_db.sql
    