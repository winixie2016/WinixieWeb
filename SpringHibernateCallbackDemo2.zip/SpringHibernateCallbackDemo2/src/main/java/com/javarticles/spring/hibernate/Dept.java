package com.javarticles.spring.hibernate;

public class Dept {

	Long   id;
	String name;
	String loc;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String dname) {
		this.name = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	
	public String toString() {
		return "id="+id+",name="+name+",loc="+loc;
	}
}
