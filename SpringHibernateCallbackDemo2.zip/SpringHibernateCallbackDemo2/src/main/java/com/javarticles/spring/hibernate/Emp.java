package com.javarticles.spring.hibernate;

import java.sql.*;

public class Emp {
	
	Long   id;
	String ename;
	String job;
	Long   mgr;
	Date   hiredate;
	Long   sal;
	Long   comm;
	Long   deptno;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Long getMgr() {
		return mgr;
	}
	public void setMgr(Long mgr) {
		this.mgr = mgr;
	}
	public Date getHiredate() {
		return hiredate;
	}
	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}
	public Long getSal() {
		return sal;
	}
	public void setSal(Long sal) {
		this.sal = sal;
	}
	public Long getComm() {
		return comm;
	}
	public void setComm(Long comm) {
		this.comm = comm;
	}
	public Long getDeptno() {
		return deptno;
	}
	public void setDeptno(Long deptno) {
		this.deptno = deptno;
	}

	@Override
	public String toString() {
		
		return ("id="+id+",ename="+ename+",job="+job+",dept="+deptno);
	}
}
