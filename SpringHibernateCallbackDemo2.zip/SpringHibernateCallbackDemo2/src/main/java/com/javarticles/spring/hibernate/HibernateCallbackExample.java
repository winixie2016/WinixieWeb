package com.javarticles.spring.hibernate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class HibernateCallbackExample {

	private HibernateTemplate hibernateTemplate;

	public static void main(String[] args) throws MappingException, IOException {

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		HibernateCallbackExample hibernateCallbackExample = (HibernateCallbackExample) context
				.getBean("hibernateCallbackExample");

		hibernateCallbackExample.execute();
	}

	@Transactional(readOnly = false)
	public void execute() {
			
		int ctr = 1;
		List<Emp> results;
		
		System.out.println("\nTest 1: find emp given id");		
		Long empID = 7369L;
		results = getEmp(empID);
		
		for (Emp emp: results) {
		    System.out.println("" + (ctr++) + ": " + emp);
		}
		
		System.out.println("\nTest 2: find emps in a dept");
		Long deptNo = 20L;
		results = getEmpsInDept(deptNo);
		
		for (Emp emp: results) {
		    System.out.println("Emp: " + emp);
		}
		
		System.out.println("\nTest 3: find emps given names");
		List<String> empList = new ArrayList<String>();
		empList.add("ALLEN");
		empList.add("KING");		
		results = hibernateCallback(empList);
		ctr = 1;
		for (Emp emp: results) {
		    System.out.println("" + (ctr++) + ": " + emp);
		}

		System.out.println("\nTest 4: find emps given id or names");				
		results = getEmps(empID, empList);
		ctr = 1;
		for (Emp emp: results) {
		    System.out.println("" + (ctr++) + ": " + emp);
		}

		System.out.println("\nDone");
	}
	
	public List<Emp> getEmp(final Long emp_id) {
				
		final String sql = "from Emp where id = :p1"; 
		// !!! Case sensitive: EMP is not mapped
		
		List<Emp> empList = hibernateTemplate.execute(new HibernateCallback<List<Emp>>() {

			public List<Emp> doInHibernate(Session session) 
			throws HibernateException {

				Query query = session.createQuery(sql);
				query.setParameter("p1", emp_id);
					
				return query.list();
			}
		}); 
		
		return empList;
	}
	
	@Transactional(readOnly = true)
	public List<Emp> hibernateCallback(final List<String> nameList) {

		System.out.println("In hibernateCallback() ......");

		final String sql = "from Emp where ename in (:dummyList)";

		List<Emp> emplist = hibernateTemplate.execute(new HibernateCallback<List<Emp>>() {

			@SuppressWarnings("unchecked")
			public List<Emp> doInHibernate(Session session) throws HibernateException {
				Query query = session.createQuery(sql);

				query.setParameterList("dummyList", nameList);

				return query.list();
			}
		});

		return emplist;
	}
	
	public List<Emp> getEmps(final Long emp_id, final List<String> emps) {

		final String sql = "from Emp where id = :p1 or ename in (:p2)";
		// !!! Case sensitive: EMP is not mapped
		
		List<Emp> result = hibernateTemplate.execute(new HibernateCallback<List<Emp>>() {

			public List<Emp> doInHibernate(Session session) 
			throws HibernateException {		
				Query query = session.createQuery(sql);
				query.setParameter("p1", emp_id)
				     .setParameterList("p2", emps);
				
				return query.list();
			}
		}); 
		
		return result;
	}
		
	public List<Emp> getEmpsInDept(final Long dept_id) {

			final String sql = "from Emp where deptno = :p";
			// !!! Case sensitive: EMP is not mapped
			
			List<Emp> result = hibernateTemplate.execute(new HibernateCallback<List<Emp>>() {

				public List<Emp> doInHibernate(Session session) 
				throws HibernateException {		
					Query query = session.createQuery(sql);
					query.setParameter("p", dept_id);
					    
					return query.list();
				}
			}); 	
			
		return result;
	}
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
}

/****************** output **************************************
 
Test 1: find emp given id
1: id=7369,ename=SMITH,job=CLERK,dept=20

Test 2: find emps in a dept
Emp: id=7369,ename=SMITH,job=CLERK,dept=20
Emp: id=7566,ename=JONES,job=MANAGER,dept=20
Emp: id=7788,ename=SCOTT,job=ANALYST,dept=20
Emp: id=7876,ename=ADAMS,job=CLERK,dept=20
Emp: id=7902,ename=FORD,job=ANALYST,dept=20

Test 3: find emps given names
In hibernateCallback() ......
1: id=7499,ename=ALLEN,job=SALESMAN,dept=30
2: id=7839,ename=KING,job=PRESIDENT,dept=10

Test 4: find emps given id or names
1: id=7369,ename=SMITH,job=CLERK,dept=20
2: id=7499,ename=ALLEN,job=SALESMAN,dept=30
3: id=7839,ename=KING,job=PRESIDENT,dept=10

Done
 ***************************************************************/
