package com.javarticles.spring.hibernate;

import java.sql.*;

public class MySqlDbConnection {
	public static void main(String args[]) {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/world", "root", "winix123");
			
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("select * from country where code in ('CHN', 'USA', 'CAN')");

			while (rs.next())
				System.out.println(rs.getString(1) + "  " + rs.getString(2));

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
}
