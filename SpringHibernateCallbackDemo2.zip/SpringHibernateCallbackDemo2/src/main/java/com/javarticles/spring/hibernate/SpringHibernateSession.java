package com.javarticles.spring.hibernate;

import java.io.IOException;
import java.util.List;

import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringHibernateSession {
	private SessionFactory sessionFactory;

	public static void main(String[] args) throws MappingException, IOException {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		SpringHibernateSession hibernateSession = (SpringHibernateSession) context
				.getBean("hibernateSession");
		hibernateSession.execute();
	}

	public void execute() throws MappingException, IOException {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.getTransaction();
		
		try {
			tx.begin();
			Query query = session.createQuery("from Employee where name='Joe'");
			List<Employee> empList = query.list();
			System.out.println("Employees found: " + empList.size());
			for (Employee emp : empList) {
				System.out.println("emp: " + emp);
				session.delete(emp);
				System.out.println("Deleted " + emp);
			}
			tx.commit();
			System.out.println("All employees are deleted ...");

			System.out.println("Create new employee Joe");
			tx = session.getTransaction();
			tx.begin();
			Employee emp = new Employee();
			emp.setName("Joe");
			emp.setContact("Joseph-"+(int)(Math.random()*100));
			session.saveOrUpdate(emp);
			tx.commit();

			query = session.createQuery("from Employee where name='Joe'");
			System.out.println("List all Employees: " + query.list());
		} catch (RuntimeException e) {
			tx.rollback();
			throw e;

		} finally {
			session.close();
		}
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
}

/************* output **********************
 
Employees found: 1
emp: Employee: name=Joe,id=89,contact=Joseph-80
Deleted Employee: name=Joe,id=89,contact=Joseph-80
All employees are deleted ...
Create new employee Joe
List all Employees: [Employee: name=Joe,id=90,contact=Joseph-95]

******************************************/
