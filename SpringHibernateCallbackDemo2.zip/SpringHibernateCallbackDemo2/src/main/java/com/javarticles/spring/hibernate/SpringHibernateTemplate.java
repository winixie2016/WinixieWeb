package com.javarticles.spring.hibernate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class SpringHibernateTemplate {

	private HibernateTemplate hibernateTemplate;

	public static void main(String[] args) throws MappingException, IOException {

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		SpringHibernateTemplate springHibernateTemplate = (SpringHibernateTemplate) context
				.getBean("springHibernateTemplate");

		springHibernateTemplate.execute();
	}

	@Transactional(readOnly = false)
	public void execute() {
		
		System.out.println("First find employees then delete them");
		List<?> employeeList = findEmployees();
		printAll(employeeList);
		
		deleteEmployees(employeeList);
		
		employeeList = findEmployees();
		System.out.println("After delete, print employees ..."); 
		printAll(employeeList);
		
		System.out.println("\nCreate an employee ...");
		Employee empJoe = new Employee();
		createEmployee("Joe");
		
		System.out.println("\nSave an employee ...");
		Employee empSam = new Employee();
		empSam.setName("Sam");
		empSam.setContact(empSam.getName() + (Math.negateExact(1000)));
		saveEmployee(empSam);
		
		employeeList = findEmployees();
		System.out.println("\nNow, print employees ..."); 
		printAll(employeeList);
		
		System.out.println("\nNow, using HibernateCallback ..."); 
		List<Employee> results = findUsingHibernateCallback();
		printAll(results);
		
		System.out.println("\nNow, using HibernateCallback another way ..."); 
		List<String> nameList = new ArrayList<String>();
		nameList.add("Joe");
		nameList.add("Sam");
		results = usingHibernateCallback(nameList);
		printAll(results);
	}

	@Transactional(readOnly = false)
	public void createEmployee(final String Name) {
		System.out.println("Create new employee " + Name);
		Employee emp = hibernateTemplate.execute(new HibernateCallback<Employee>() {

			public Employee doInHibernate(Session session) throws HibernateException {
				Employee emp = new Employee();
				emp.setName(Name);
				emp.setContact(Name + (Math.negateExact(1000)));
				session.saveOrUpdate(emp);
				return emp;
			}
		});		
	}

	@Transactional(readOnly = false)
	public void saveEmployee(Employee emp) {
		System.out.println("Create new employee " + emp);
		hibernateTemplate.save(emp);	
	}

	@Transactional(readOnly = true)
	public List<?> findEmployees() {
		
		final String sql = "from Employee where name in (?, ?)";
		List<?> empList = hibernateTemplate.find(sql, "Joe", "Sam");
		
		return empList;
	}

	@Transactional(readOnly = true)
	public List<Employee> findUsingHibernateCallback() {

		final String sql = "from Employee where name in (?, ?)";

		List<Employee> emplist = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Query query = session.createQuery(sql);
				query.setParameter(0, "Joe");
				query.setParameter(1, "Sam");

				return query.list();
			}
		});

		return emplist;
	}

	@Transactional(readOnly = true)
	public List<Employee> usingHibernateCallback(final List<String> nameList) {
		
		final String sql = "from Employee where name in (:placeHolder)";

		List<Employee> emplist = hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@SuppressWarnings("unchecked")
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Query query = session.createQuery(sql);

				query.setParameterList("placeHolder", nameList);

				return query.list();
			}
		});

		return emplist;
	}

	@Transactional(readOnly = false)
	public void deleteEmployees(List<?> empList) {
		if (!empList.isEmpty()) {
			hibernateTemplate.deleteAll(empList);
			System.out.println("\nAll employees deleted");
		}
	}
	
	public void printAll(List<?> emps) {
		
		if ((emps == null) || (emps.size()==0))
			System.out.println("No employee found ...");
		
		int ctr =  1;
		for (Object emp: emps) {
		    System.out.println("" + (ctr++) + ": " + emp);
		}
	}
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
}

/****************** output **********************************

First find employees then delete them
1: Employee: name=Joe,id=80,contact=Joe-1000
2: Employee: name=Sam,id=81,contact=Sam-1000

All employees deleted
After delete, print employees ...
No employee found ...

Create an employee ...
Create new employee Joe

Save an employee ...
Create new employee Employee: name=Sam,id=0,contact=Sam-1000

Now, print employees ...
1: Employee: name=Joe,id=82,contact=Joe-1000
2: Employee: name=Sam,id=83,contact=Sam-1000

Now, using HibernateCallback ...
1: Employee: name=Joe,id=82,contact=Joe-1000
2: Employee: name=Sam,id=83,contact=Sam-1000

Now, using HibernateCallback another way ...
1: Employee: name=Joe,id=82,contact=Joe-1000
2: Employee: name=Sam,id=83,contact=Sam-1000

*******************************************************/
