package com.javarticles.spring.hibernate;

import java.io.IOException;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class SpringTxnUsingHibernate {
    private SessionFactory sessionFactory;
    public static void main(String[] args) throws MappingException, IOException {
       
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        
    	SpringTxnUsingHibernate springTxnUsingHibernate = (SpringTxnUsingHibernate) context.getBean("springTxnUsingHibernate");
        
        springTxnUsingHibernate.execute();
    }
    
    @Transactional(readOnly=false)
    public void execute() {
        List<?> empList = findEmployees();
        deleteEmployees(empList);
        createEmployee("Joe");
        Employee empSam = new Employee();
        empSam.setName("Sam");
        empSam.setContact(empSam.getName()+"-"+(int)(Math.random()*1000));
        saveEmployee(empSam);
        
        printAll(findEmployees());
    }
    
    @Transactional(readOnly=true)
    public List<?> findEmployees() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("from Employee where name in (?, ?, ?)");
        query.setParameter(0, "Joe");
        query.setParameter(1, "Sam");
        query.setParameter(2, "John");
        List<?> empList = query.list();
        System.out.println("Employees found: " + empList.size());
        return empList;
    }
    
    @Transactional(readOnly=false)
    public void deleteEmployees(List<?> empList) {
        if (!empList.isEmpty()) {
            Session session = sessionFactory.getCurrentSession();
            for (Object emp : empList) {
                session.delete(emp);
            }
            System.out.println("Employees deleted ...");
        }
    }
     
    @Transactional(readOnly=false)
    public void createEmployee(String name){
        System.out.println("Create new employee " + name);
        Session session = sessionFactory.getCurrentSession();
        Employee emp = new Employee();
        emp.setName(name);
        emp.setContact(""+name+"-"+(int)(Math.random()*1000));
        session.saveOrUpdate(emp);
        System.out.println("Employee created ...");
    }
    
    @Transactional(readOnly=false)
    public void saveEmployee(Employee emp){
        System.out.println("Create new employee " + emp);
        Session session = sessionFactory.getCurrentSession();
        session.save(emp);
        System.out.println("Employee saved ...");        
    }
    
	public void printAll(List<?> emps) {
		
		if ((emps == null) || (emps.size()==0))
			System.out.println("No employee found ...");
		
		int ctr =  1;
		for (Object emp: emps) {
		    System.out.println("" + (ctr++) + ": " + emp);
		}
	}
	
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }    
}

/******************** output, Feb 03, 2017 **********************
 
Employees found: 2
Employees deleted ...
Create new employee Joe
Employee created ...
Create new employee Employee: name=Sam,id=0,contact=Sam-512
Employee saved ...
Employees found: 2
1: Employee: name=Joe,id=101,contact=Joe-436
2: Employee: name=Sam,id=102,contact=Sam-512

***************************************************************/
