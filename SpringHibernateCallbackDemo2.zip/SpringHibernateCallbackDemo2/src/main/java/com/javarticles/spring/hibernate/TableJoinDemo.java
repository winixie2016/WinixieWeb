package com.javarticles.spring.hibernate;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

public class TableJoinDemo extends HibernateDaoSupport {

	// Note: in Dept use name instead of dname (db)
	private static final String EMP_DEPT_JOIN_SQL = 
		   "select e.id, e.ename, d.loc " + 
	       "from Emp e, Dept d " + 
		   "where e.deptno = d.id and " + 
	       "d.name=:dept_name and e.mgr=:mgr_id";
	
    public static void main(String[] args) {
    	
    	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    	TableJoinDemo tableJoinDemo = (TableJoinDemo) context.getBean("tableJoinDemo");

    	tableJoinDemo.execute();    	    	
    }
    
    public void execute() {
	  
    	String[] paraNames = {"dept_name", "mgr_id"};
    	Object[] values = {"SALES", 7698L};
    	
    	List<Object[]> objectList = (List<Object[]>)getHibernateTemplate().findByNamedParam(EMP_DEPT_JOIN_SQL, 
    			paraNames, values);
    	
    	int ctr = 1;
        for (Object[] objects: objectList) {        	
        	System.out.println(""+(ctr++)+": id=" + objects[0]+",name="+objects[1]+",location="+objects[2]);
        }
    }
}

/************************ output **************
1: id=7499,name=ALLEN,location=CHICAGO
2: id=7521,name=WARD,location=CHICAGO
3: id=7654,name=MARTIN,location=CHICAGO
4: id=7844,name=TURNER,location=CHICAGO
5: id=7900,name=JAMES,location=CHICAGO
**********************************************/
