=========

## Mockito Mocks into Spring Beans


### Relevant Articles: 
- [Injecting Mockito Mocks into Spring Beans](http://www.baeldung.com/injecting-mocks-in-spring)
