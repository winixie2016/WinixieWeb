// readme_cxie.txt
// 02/20/2017

Injecting Mockito Mocks into Spring Beans

http://www.baeldung.com/injecting-mocks-in-spring

In real-world applications, where components often depend on 
accessing external systems, it is important to provide proper 
test isolation so that we can focus on testing the functionality 
of a given unit without having to involve the whole class 
hierarchy for each test.

Injecting a mock is a clean way to introduce such isolation.

We use Spring Boot for this example, but classic Spring will also work fine.