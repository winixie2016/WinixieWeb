package com.baeldung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// standard Spring Boot main class to scan the beans and initialize the application
	
@SpringBootApplication
public class MocksApplication {
    public static void main(String[] args) {
    	
    	System.out.println("Starting MocksApplication ...");
    	
        SpringApplication.run(MocksApplication.class, args);
    }
}
