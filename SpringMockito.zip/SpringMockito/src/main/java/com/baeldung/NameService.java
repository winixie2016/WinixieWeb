package com.baeldung;

import org.springframework.stereotype.Service;

// This is the business logic that will be tested
// It will be injected into UserService 

@Service
public class NameService {
    public String getUserName(String id) {
    	
    	System.out.println("In NameService.getUserName(...), id: " + id);
    	
        return "Real user name --- Lin Yinxgue";
    }
}
