package com.baeldung;

import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

// The @Profile annotation tells Spring to apply this configuration only 
// when the “test” profile is active. 

// The @Primary annotation is there to make sure this this instance is 
// used instead of a real one for autowiring.  The method itself creates 
// and returns a Mockito mock of our NameService class.

@Profile("mytest")
@Configuration
public class NameServiceTestConfiguration {
    @Bean
    @Primary
    public NameService nameService() {
        return Mockito.mock(NameService.class);
    }
}
