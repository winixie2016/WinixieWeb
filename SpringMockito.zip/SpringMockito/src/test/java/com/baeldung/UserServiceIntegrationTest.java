package com.baeldung;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**************************************************************
 
We use the @ActiveProfiles annotation to enable the “test” 
profile and activate the mock configuration we wrote earlier. 
Because of this, Spring autowires a real instance of the 
UserService class, but a mock of the NameService class. 
The test itself is a fairly typical JUnit+Mockito test. 
We configure the desired behavior of the mock, then call 
the method which we want to test and assert that it returns 
the value that we expect.

It is also possible (though not recommended) to avoid 
using environment profiles in such tests. To do so, 
remove the @Profile and @ActiveProfiles annotations and add an 
@ContextConfiguration(classes = NameServiceTestConfiguration.class) 
annotation to the UserServiceTest class.

********************************************************/

@ActiveProfiles("mytest")
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = MocksApplication.class)
public class UserServiceIntegrationTest {

    @Autowired
    private UserService userService;

    @Autowired
    private NameService nameService;

    @Test
    public void whenUserIdIsProvided_thenRetrievedNameIsCorrect() {
        Mockito.when(nameService.getUserName("SomeId")).thenReturn("Mock user name");

        String testName = userService.getUserName("SomeId");

        System.out.println("testName: " + testName);
        
        Assert.assertEquals("Mock user name", testName);
    }
}

/******************* output ********************
10:35:43.723 [main] DEBUG org.springframework.test.context.junit4.SpringJUnit4ClassRunner - SpringJUnit4ClassRunner constructor called with [class com.baeldung.UserServiceIntegrationTest]
10:35:43.727 [main] DEBUG org.springframework.test.context.BootstrapUtils - Instantiating CacheAwareContextLoaderDelegate from class [org.springframework.test.context.cache.DefaultCacheAwareContextLoaderDelegate]
10:35:43.732 [main] DEBUG org.springframework.test.context.BootstrapUtils - Instantiating BootstrapContext using constructor [public org.springframework.test.context.support.DefaultBootstrapContext(java.lang.Class,org.springframework.test.context.CacheAwareContextLoaderDelegate)]
10:35:43.740 [main] DEBUG org.springframework.test.context.BootstrapUtils - Instantiating TestContextBootstrapper for test class [com.baeldung.UserServiceIntegrationTest] from class [org.springframework.test.context.support.DefaultTestContextBootstrapper]
10:35:43.755 [main] DEBUG org.springframework.test.context.support.DefaultTestContextBootstrapper - Found explicit ContextLoader class [org.springframework.boot.test.SpringApplicationContextLoader] for context configuration attributes [ContextConfigurationAttributes@39ba5a14 declaringClass = 'com.baeldung.UserServiceIntegrationTest', classes = '{class com.baeldung.MocksApplication}', locations = '{}', inheritLocations = true, initializers = '{}', inheritInitializers = true, name = [null], contextLoaderClass = 'org.springframework.boot.test.SpringApplicationContextLoader']
10:35:43.761 [main] DEBUG org.springframework.test.context.support.AbstractContextLoader - Did not detect default resource location for test class [com.baeldung.UserServiceIntegrationTest]: class path resource [com/baeldung/UserServiceIntegrationTest-context.xml] does not exist
10:35:43.761 [main] DEBUG org.springframework.test.context.support.AbstractContextLoader - Did not detect default resource location for test class [com.baeldung.UserServiceIntegrationTest]: class path resource [com/baeldung/UserServiceIntegrationTestContext.groovy] does not exist
10:35:43.761 [main] INFO org.springframework.test.context.support.AbstractContextLoader - Could not detect default resource locations for test class [com.baeldung.UserServiceIntegrationTest]: no resource found for suffixes {-context.xml, Context.groovy}.
10:35:43.790 [main] DEBUG org.springframework.test.context.support.DefaultTestContextBootstrapper - @TestExecutionListeners is not present for class [com.baeldung.UserServiceIntegrationTest]: using defaults.
10:35:43.794 [main] INFO org.springframework.test.context.support.DefaultTestContextBootstrapper - Loaded default TestExecutionListener class names from location [META-INF/spring.factories]: [org.springframework.boot.test.mock.mockito.MockitoTestExecutionListener, org.springframework.boot.test.mock.mockito.ResetMocksTestExecutionListener, org.springframework.boot.test.autoconfigure.restdocs.RestDocsTestExecutionListener, org.springframework.boot.test.autoconfigure.web.client.MockRestServiceServerResetTestExecutionListener, org.springframework.boot.test.autoconfigure.web.servlet.MockMvcPrintOnlyOnFailureTestExecutionListener, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverTestExecutionListener, org.springframework.test.context.web.ServletTestExecutionListener, org.springframework.test.context.support.DirtiesContextBeforeModesTestExecutionListener, org.springframework.test.context.support.DependencyInjectionTestExecutionListener, org.springframework.test.context.support.DirtiesContextTestExecutionListener, org.springframework.test.context.transaction.TransactionalTestExecutionListener, org.springframework.test.context.jdbc.SqlScriptsTestExecutionListener]
10:35:43.798 [main] INFO org.springframework.test.context.support.DefaultTestContextBootstrapper - Could not instantiate TestExecutionListener [org.springframework.test.context.transaction.TransactionalTestExecutionListener]. Specify custom listener classes or make the default listener classes (and their required dependencies) available. Offending class: [org/springframework/transaction/interceptor/TransactionAttributeSource]
10:35:43.798 [main] INFO org.springframework.test.context.support.DefaultTestContextBootstrapper - Could not instantiate TestExecutionListener [org.springframework.test.context.jdbc.SqlScriptsTestExecutionListener]. Specify custom listener classes or make the default listener classes (and their required dependencies) available. Offending class: [org/springframework/transaction/interceptor/TransactionAttribute]
10:35:43.799 [main] INFO org.springframework.test.context.support.DefaultTestContextBootstrapper - Could not instantiate TestExecutionListener [org.springframework.test.context.web.ServletTestExecutionListener]. Specify custom listener classes or make the default listener classes (and their required dependencies) available. Offending class: [javax/servlet/ServletContext]
10:35:43.800 [main] INFO org.springframework.test.context.support.DefaultTestContextBootstrapper - Using TestExecutionListeners: [org.springframework.test.context.support.DirtiesContextBeforeModesTestExecutionListener@57baeedf, org.springframework.test.context.support.DependencyInjectionTestExecutionListener@343f4d3d, org.springframework.test.context.support.DirtiesContextTestExecutionListener@53b32d7, org.springframework.boot.test.autoconfigure.web.servlet.MockMvcPrintOnlyOnFailureTestExecutionListener@5442a311, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverTestExecutionListener@548e7350, org.springframework.boot.test.mock.mockito.MockitoTestExecutionListener@1a968a59, org.springframework.boot.test.autoconfigure.web.client.MockRestServiceServerResetTestExecutionListener@4667ae56, org.springframework.boot.test.mock.mockito.ResetMocksTestExecutionListener@77cd7a0, org.springframework.boot.test.autoconfigure.restdocs.RestDocsTestExecutionListener@204f30ec]
10:35:43.801 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [com.baeldung.UserServiceIntegrationTest]
10:35:43.801 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [com.baeldung.UserServiceIntegrationTest]
10:35:43.808 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [com.baeldung.UserServiceIntegrationTest]
10:35:43.808 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [com.baeldung.UserServiceIntegrationTest]
10:35:43.809 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [com.baeldung.UserServiceIntegrationTest]
10:35:43.809 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [com.baeldung.UserServiceIntegrationTest]
10:35:43.810 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [com.baeldung.UserServiceIntegrationTest]
10:35:43.810 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [com.baeldung.UserServiceIntegrationTest]
10:35:43.811 [main] DEBUG org.springframework.test.context.support.AbstractDirtiesContextTestExecutionListener - Before test class: context [DefaultTestContext@6e06451e testClass = UserServiceIntegrationTest, testInstance = [null], testMethod = [null], testException = [null], mergedContextConfiguration = [MergedContextConfiguration@59494225 testClass = UserServiceIntegrationTest, locations = '{}', classes = '{class com.baeldung.MocksApplication}', contextInitializerClasses = '[]', activeProfiles = '{mytest}', propertySourceLocations = '{}', propertySourceProperties = '{}', contextCustomizers = set[org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@4590c9c3, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@0, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizerFactory$Customizer@51081592], contextLoader = 'org.springframework.boot.test.SpringApplicationContextLoader', parent = [null]]], class annotated with @DirtiesContext [false] with mode [null].
10:35:43.812 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved @ProfileValueSourceConfiguration [null] for test class [com.baeldung.UserServiceIntegrationTest]
10:35:43.812 [main] DEBUG org.springframework.test.annotation.ProfileValueUtils - Retrieved ProfileValueSource type [class org.springframework.test.annotation.SystemProfileValueSource] for class [com.baeldung.UserServiceIntegrationTest]
10:35:43.813 [main] DEBUG org.springframework.test.context.support.DependencyInjectionTestExecutionListener - Performing dependency injection for test context [[DefaultTestContext@6e06451e testClass = UserServiceIntegrationTest, testInstance = com.baeldung.UserServiceIntegrationTest@ff5b51f, testMethod = [null], testException = [null], mergedContextConfiguration = [MergedContextConfiguration@59494225 testClass = UserServiceIntegrationTest, locations = '{}', classes = '{class com.baeldung.MocksApplication}', contextInitializerClasses = '[]', activeProfiles = '{mytest}', propertySourceLocations = '{}', propertySourceProperties = '{}', contextCustomizers = set[org.springframework.boot.test.context.filter.ExcludeFilterContextCustomizer@4590c9c3, org.springframework.boot.test.mock.mockito.MockitoContextCustomizer@0, org.springframework.boot.test.autoconfigure.properties.PropertyMappingContextCustomizer@0, org.springframework.boot.test.autoconfigure.web.servlet.WebDriverContextCustomizerFactory$Customizer@51081592], contextLoader = 'org.springframework.boot.test.SpringApplicationContextLoader', parent = [null]]]].
10:35:43.857 [main] DEBUG org.springframework.core.env.StandardEnvironment - Adding [systemProperties] PropertySource with lowest search precedence
10:35:43.857 [main] DEBUG org.springframework.core.env.StandardEnvironment - Adding [systemEnvironment] PropertySource with lowest search precedence
10:35:43.857 [main] DEBUG org.springframework.core.env.StandardEnvironment - Initialized StandardEnvironment with PropertySources [systemProperties,systemEnvironment]
10:35:43.858 [main] DEBUG org.springframework.core.env.StandardEnvironment - Adding [test] PropertySource with highest search precedence
10:35:43.858 [main] DEBUG org.springframework.core.env.StandardEnvironment - Adding [integrationTest] PropertySource with search precedence immediately lower than [systemEnvironment]

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::        (v1.4.2.RELEASE)

2017-02-20 10:35:44.038  INFO 2912 --- [           main] com.baeldung.UserServiceIntegrationTest  : Starting UserServiceIntegrationTest on DELLDESKTOP8700 with PID 2912 (started by Albert in C:\temp\workbench\workbench-spring\SpringMockito)
2017-02-20 10:35:44.038  INFO 2912 --- [           main] com.baeldung.UserServiceIntegrationTest  : The following profiles are active: mytest
2017-02-20 10:35:44.066  INFO 2912 --- [           main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.AnnotationConfigApplicationContext@636be97c: startup date [Mon Feb 20 10:35:44 EST 2017]; root of context hierarchy
2017-02-20 10:35:44.323  INFO 2912 --- [           main] o.s.b.f.s.DefaultListableBeanFactory     : Overriding bean definition for bean 'nameService' with a different definition: replacing [Generic bean: class [com.baeldung.NameService]; scope=singleton; abstract=false; lazyInit=false; autowireMode=0; dependencyCheck=0; autowireCandidate=true; primary=false; factoryBeanName=null; factoryMethodName=null; initMethodName=null; destroyMethodName=null; defined in file [C:\temp\workbench\workbench-spring\SpringMockito\target\classes\com\baeldung\NameService.class]] with [Root bean: class [null]; scope=; abstract=false; lazyInit=false; autowireMode=3; dependencyCheck=0; autowireCandidate=true; primary=true; factoryBeanName=nameServiceTestConfiguration; factoryMethodName=nameService; initMethodName=null; destroyMethodName=(inferred); defined in class path resource [com/baeldung/NameServiceTestConfiguration.class]]
2017-02-20 10:35:44.590  INFO 2912 --- [           main] com.baeldung.UserServiceIntegrationTest  : Started UserServiceIntegrationTest in 0.729 seconds (JVM running for 1.086)
testName: Mock user name
2017-02-20 10:35:44.615  INFO 2912 --- [       Thread-1] s.c.a.AnnotationConfigApplicationContext : Closing org.springframework.context.annotation.AnnotationConfigApplicationContext@636be97c: startup date [Mon Feb 20 10:35:44 EST 2017]; root of context hierarchy
*************************************/