// readme_cxie.txt
// 09/05/2016

https://avaldes.com/spring-restful-web-service-example-with-json-and-jackson-using-spring-tool-suite/

