// readme_cxie.txt
// 09/05/2016

http://www.concretepage.com/spring/spring-mvc/spring-rest-client-resttemplate-consume-restful-web-service-example-xml-json

C:\...\> gradle war

Deploy the generated war file spring-rst-1.war in Tomat

Start Tomcat if it is not running

It demos @RequestBody
