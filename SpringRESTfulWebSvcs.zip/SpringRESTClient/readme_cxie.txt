// readme_cxie.txt
// 09/05/2016

http://www.concretepage.com/spring/spring-mvc/spring-rest-client-resttemplate-consume-restful-web-service-example-xml-json

Step 1: Build and deploy RESTServiceDemo first

Step 2: Use Eclipse to import the existing project 

Step 3: Run individual tests 

Successfully !

Client Side also needs Address.java, Company.java and Person.java
