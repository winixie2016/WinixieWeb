package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.RestTemplate;

public class DeleteDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/delete/{name}/{village}";
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "Mahesh");
        map.put("village", "Dhananjaypur");
        restTemplate.delete(url, map);
    }
}

/************************ output ********************

15:35:18.418 [main] DEBUG o.s.web.client.RestTemplate - Created DELETE request for "http://localhost:8080/spring-rest-1/data/delete/Mahesh/Dhananjaypur"
15:35:18.447 [main] DEBUG o.s.web.client.RestTemplate - DELETE request for "http://localhost:8080/spring-rest-1/data/delete/Mahesh/Dhananjaypur" resulted in 200 (OK)

****************************************************/
