package com.concretepage;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class ExchangeDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
		String uri = "http://localhost:8080/spring-rest-1/data/exchange/{id}";
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<String>("Hello World!", headers);
        ResponseEntity<Person> personEntity = restTemplate.exchange(uri, HttpMethod.GET, entity, Person.class, 100);
        System.out.println("ID:"+personEntity.getBody().getId());
        System.out.println("Name:"+personEntity.getBody().getName());
        System.out.println("Village:"+personEntity.getBody().getAddress().getVillage());
    }
}

/************** output *****************

15:28:24.385 [main] DEBUG o.s.web.client.RestTemplate - Created GET request for "http://localhost:8080/spring-rest-1/data/exchange/100"
15:28:24.414 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/json, application/*+json]
15:28:24.415 [main] DEBUG o.s.web.client.RestTemplate - Writing [Hello World!] as "application/json" using [org.springframework.http.converter.StringHttpMessageConverter@782663d3]
15:28:24.441 [main] DEBUG o.s.web.client.RestTemplate - GET request for "http://localhost:8080/spring-rest-1/data/exchange/100" resulted in 200 (OK)
15:28:24.442 [main] DEBUG o.s.web.client.RestTemplate - Reading [class com.concretepage.Person] as "application/json" using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@5c072e3f]
ID:100
Name:Mahesh
Village:Dhananjaypur

***************************************/
