package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class GetForEntityDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/fetch/{name}/{village}";
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "Mahesh");
        map.put("village", "Dhananjaypur");
        ResponseEntity<Person> personEntity = restTemplate.getForEntity(url, Person.class, map);
        System.out.println("Name:"+personEntity.getBody().getName());
        System.out.println("Village:"+personEntity.getBody().getAddress().getVillage());
    }
}

/***************** output ******************

15:28:50.528 [main] DEBUG o.s.web.client.RestTemplate - Created GET request for "http://localhost:8080/spring-rest-1/data/fetch/Mahesh/Dhananjaypur"
15:28:50.559 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/json, application/*+json]
15:28:50.584 [main] DEBUG o.s.web.client.RestTemplate - GET request for "http://localhost:8080/spring-rest-1/data/fetch/Mahesh/Dhananjaypur" resulted in 200 (OK)
15:28:50.585 [main] DEBUG o.s.web.client.RestTemplate - Reading [class com.concretepage.Person] as "application/json;charset=UTF-8" using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@401e7803]
Name:Mahesh
Village:Dhananjaypur

*******************************************/
