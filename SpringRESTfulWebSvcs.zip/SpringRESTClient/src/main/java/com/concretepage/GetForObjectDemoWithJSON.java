package com.concretepage;

import org.springframework.web.client.RestTemplate;

public class GetForObjectDemoWithJSON {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        Person person = restTemplate.getForObject("http://localhost:8080/spring-rest-1/data/fetchjson/{id}", Person.class, 200);
        System.out.println("ID: " + person.getId());
        System.out.println("Name: " + person.getName());
        System.out.println("Village Name: " + person.getAddress().getVillage());
    }
}

/*************** output ********************

15:25:22.355 [main] DEBUG o.s.web.client.RestTemplate - Created GET request for "http://localhost:8080/spring-rest-1/data/fetchjson/200"
15:25:22.385 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/json, application/*+json]
15:25:22.409 [main] DEBUG o.s.web.client.RestTemplate - GET request for "http://localhost:8080/spring-rest-1/data/fetchjson/200" resulted in 200 (OK)
15:25:22.410 [main] DEBUG o.s.web.client.RestTemplate - Reading [class com.concretepage.Person] as "application/json" using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@150c158]
ID: 200
Name: Ram
Village Name: Dhananjaypur

*******************************************/