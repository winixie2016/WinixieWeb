package com.concretepage;

import org.springframework.web.client.RestTemplate;

public class GetForObjectDemoWithXML {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        Company company = restTemplate.getForObject("http://localhost:8080/spring-rest-1/data/fetchxml/{id}", Company.class, 200);
        System.out.println("ID: " + company.getId());
        System.out.println("Company: " + company.getCompanyName());
        System.out.println("CEO: " + company.getCeoName());
    }
}

/************** output *********************

15:34:41.381 [main] DEBUG o.s.web.client.RestTemplate - Created GET request for "http://localhost:8080/spring-rest-1/data/fetchxml/200"
15:34:41.412 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/xml, text/xml, application/json, application/*+xml, application/*+json]
15:34:41.439 [main] DEBUG o.s.web.client.RestTemplate - GET request for "http://localhost:8080/spring-rest-1/data/fetchxml/200" resulted in 200 (OK)
15:34:41.439 [main] DEBUG o.s.web.client.RestTemplate - Reading [com.concretepage.Company] as "application/xml" using [org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter@2eda0940]
ID: 200
Company: XYZ
CEO: ABCD

******************************************/
