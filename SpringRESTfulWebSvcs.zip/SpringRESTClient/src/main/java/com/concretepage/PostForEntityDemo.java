package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class PostForEntityDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/saveinfo/{id}/{name}";
        Map<String, String> map = new HashMap<String, String>();
        map.put("id", "111");
        map.put("name", "Shyam");
		Address address = new Address("Dhananjaypur", "Varanasi", "UP");
        ResponseEntity<Person> entity= restTemplate.postForEntity(url, address, Person.class, map);
        System.out.println(entity.getBody().getName());
        System.out.println(entity.getBody().getAddress().getVillage());
    }
}
 
/************** output *******************

15:29:37.371 [main] DEBUG o.s.web.client.RestTemplate - Created POST request for "http://localhost:8080/spring-rest-1/data/saveinfo/111/Shyam"
15:29:37.401 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/json, application/*+json]
15:29:37.410 [main] DEBUG o.s.web.client.RestTemplate - Writing [com.concretepage.Address@6d3af739] using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@1da51a35]
15:29:37.441 [main] DEBUG o.s.web.client.RestTemplate - POST request for "http://localhost:8080/spring-rest-1/data/saveinfo/111/Shyam" resulted in 201 (Created)
15:29:37.442 [main] DEBUG o.s.web.client.RestTemplate - Reading [class com.concretepage.Person] as "application/json;charset=UTF-8" using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@1da51a35]
Shyam
Dhananjaypur

****************************************/
