package com.concretepage;

import java.net.URI;

import org.springframework.web.client.RestTemplate;

public class PostForLocationDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/location/{id}/{name}";
		Address address = new Address("Dhananjaypur", "Varanasi", "UP");
		URI uri= restTemplate.postForLocation(url, address, 111, "Shyam");
		System.out.println(uri.getPath());
    }
}

/*********** output **************
 
15:32:26.394 [main] DEBUG o.s.web.client.RestTemplate - Created POST request for "http://localhost:8080/spring-rest-1/data/location/111/Shyam"
15:32:26.419 [main] DEBUG o.s.web.client.RestTemplate - Writing [com.concretepage.Address@23fe1d71] using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@28ac3dc3]
15:32:26.456 [main] DEBUG o.s.web.client.RestTemplate - POST request for "http://localhost:8080/spring-rest-1/data/location/111/Shyam" resulted in 201 (Created)
/spring-rest-1/location/111/Shyam

**********************************/
