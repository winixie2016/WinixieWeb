package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.RestTemplate;

public class PostForObjectDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/saveinfo/{id}/{name}";
        Map<String, String> map = new HashMap<String, String>();
        map.put("id", "111");
        map.put("name", "Shyam");
		Address address = new Address("Dhananjaypur", "Varanasi", "UP");
        Person person= restTemplate.postForObject(url, address, Person.class, map);
        
        System.out.println(person.getName());
        System.out.println(person.getAddress().getVillage());
    }
}
 
/************** output ******************

15:32:59.342 [main] DEBUG o.s.web.client.RestTemplate - Created POST request for "http://localhost:8080/spring-rest-1/data/saveinfo/111/Shyam"
15:32:59.373 [main] DEBUG o.s.web.client.RestTemplate - Setting request Accept header to [application/json, application/*+json]
15:32:59.383 [main] DEBUG o.s.web.client.RestTemplate - Writing [com.concretepage.Address@4ae82894] using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@543788f3]
15:32:59.412 [main] DEBUG o.s.web.client.RestTemplate - POST request for "http://localhost:8080/spring-rest-1/data/saveinfo/111/Shyam" resulted in 201 (Created)
15:32:59.413 [main] DEBUG o.s.web.client.RestTemplate - Reading [class com.concretepage.Person] as "application/json;charset=UTF-8" using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@543788f3]
Shyam
Dhananjaypur

***************************************/
