package com.concretepage;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.client.RestTemplate;

public class PutDemo {
    public static void main(String args[]) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "http://localhost:8080/spring-rest-1/data/putdata/{id}/{name}";
        Map<String, String> map = new HashMap<String, String>();
        map.put("id", "100");
        map.put("name", "Ram");
        Address address = new Address("Dhananjaypur", "Varanasi","UP");
        restTemplate.put(url, address, map);
    }
}

/*************** output ******************

15:33:30.531 [main] DEBUG o.s.web.client.RestTemplate - Created PUT request for "http://localhost:8080/spring-rest-1/data/putdata/100/Ram"
15:33:30.556 [main] DEBUG o.s.web.client.RestTemplate - Writing [com.concretepage.Address@23fe1d71] using [org.springframework.http.converter.json.MappingJackson2HttpMessageConverter@28ac3dc3]
15:33:30.590 [main] DEBUG o.s.web.client.RestTemplate - PUT request for "http://localhost:8080/spring-rest-1/data/putdata/100/Ram" resulted in 200 (OK)

****************************************/
