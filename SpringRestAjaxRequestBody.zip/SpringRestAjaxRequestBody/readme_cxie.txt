// readme_cxie.txt
// 1/24/207

http://www.mkyong.com/spring-mvc/spring-4-mvc-ajax-hello-world-example/

Successful!

It demos @RequestBody

Step 1: mvn clean install

Step 2: Copy *.war to ~tomcat/webapps

Step 3: start Tomcat

Step 4: Open URL http://localhost:8080/spring4-mvc-maven-ajax-jquery
