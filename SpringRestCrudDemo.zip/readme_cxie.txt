// readme_cxie.txt
// 1/24/2017

http://websystique.com/springmvc/spring-mvc-4-restful-web-services-crud-example-resttemplate/
(08/11/2015)

This project shows:

      (1) uses RestTemplate from Spring (org.springframework.web.client.RestTemplate)
      (2) no web.xml 
      (3) Use @RequestBody

Step 1: build the project
        C:\...>mvn clean install
        
Step 2: Copy the war file Spring4MVCCRUDRestService.war to ~tomcat\webapps

Step 3: start Tomcat 

Step 4: Run SpringRestTestClient.java as an Application

------------------ In Eclipse --------------------

1. Start the project "Run on Server"
2. Run SpringRestTestClient.java as Application

