// readme_cxie.txt
// 02/18/2017

http://memorynotfound.com/unit-test-spring-mvc-rest-service-junit-mockito/

Remark 0: Unit Test Spring MVC Rest Service: MockMVC, JUnit, Mockito

Remark 1: This project does not have web.xml.
          Its configuration is in Java.
        
Remarkk 2: It shows how to use servlet filter.        
        
Step 1: Run UserControllerUnitTest.java as JUnit Test.
        It is successful.
        Do not need any server side running.
        
Step 2: To run UserControllerIntegrationTest.java, need to make the file 
        as *.log in order not to block the build. The run
        
        mvn clean install
        
        If it is successful, *.war file will be generated.
        Deploy the war file in Tomcat.
        Start Tomcat
        
        Now rename the file back to *.java.
        Change the BASE_URI based on the context of the deployed war file.
        
        Now run it as "JUnit Test".
       
        It is successful.
        