package com.memorynotfound.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.memorynotfound.config.WebConfig;
import com.memorynotfound.controller.UserController;
import com.memorynotfound.filter.CORSFilter;
import com.memorynotfound.model.User;
import com.memorynotfound.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.Arrays;
import java.util.List;
import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {WebConfig.class})
public class UserControllerUnitTest {

    private MockMvc mockMvc;

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(userController)
        		                 .addFilters(new CORSFilter())
        		                 .build();
    }

    // ===================== Get All Users ===================

    @Test
    public void test_get_all_success() throws Exception {
        List<User> users = Arrays.asList(
                new User(1, "Daenerys Targaryen"),
                new User(2, "John Snow"));

        when(userService.getAll()).thenReturn(users);

        mockMvc.perform(get("/users"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].id", is(1)))
                .andExpect(jsonPath("$[0].username", is("Daenerys Targaryen")))
                .andExpect(jsonPath("$[1].id", is(2)))
                .andExpect(jsonPath("$[1].username", is("John Snow")));

        verify(userService, times(1)).getAll();
        verifyNoMoreInteractions(userService);
    }

    // =========================================== Get User By ID =========================================

    @Test
    public void test_get_by_id_success() throws Exception {
        User user = new User(1, "Daenerys Targaryen");

        when(userService.findById(1)).thenReturn(user);

        mockMvc.perform(get("/users/{id}", 1))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
                .andExpect(jsonPath("$.id", is(1)))
                .andExpect(jsonPath("$.username", is("Daenerys Targaryen")));

        verify(userService, times(1)).findById(1);
        verifyNoMoreInteractions(userService);
    }

    @Test
    public void test_get_by_id_fail_404_not_found() throws Exception {
        when(userService.findById(1)).thenReturn(null);

        mockMvc.perform(get("/users/{id}", 1))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).findById(1);
        verifyNoMoreInteractions(userService);
    }

    // ===================== Create New User ===============================

    @Test
    public void test_create_user_success() throws Exception {
        User user = new User("Arya Stark");

        when(userService.exists(user)).thenReturn(false);
        doNothing().when(userService).create(user);

        mockMvc.perform(
                post("/users")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(user)))
                .andExpect(status().isCreated())
                .andExpect(header().string("location", containsString("/users/0")));

        verify(userService, times(1)).exists(user);
        verify(userService, times(1)).create(user);
        verifyNoMoreInteractions(userService);
    }

    @Test
    public void test_create_user_fail_404_not_found() throws Exception {
        User user = new User("username exists");

        when(userService.exists(user)).thenReturn(true);

        mockMvc.perform(
                post("/users")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(user)))
                .andExpect(status().isConflict());

        verify(userService, times(1)).exists(user);
        verifyNoMoreInteractions(userService);
    }

    // =================== Update Existing User ===================================

    @Test
    public void test_update_user_success() throws Exception {
        User user = new User(1, "Arya Stark");

        when(userService.findById(user.getId())).thenReturn(user);
        doNothing().when(userService).update(user);

        mockMvc.perform(
                put("/users/{id}", user.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(user)))
                .andExpect(status().isOk());

        verify(userService, times(1)).findById(user.getId());
        verify(userService, times(1)).update(user);
        verifyNoMoreInteractions(userService);
    }

    @Test
    public void test_update_user_fail_404_not_found() throws Exception {
        User user = new User(999, "user not found");

        when(userService.findById(user.getId())).thenReturn(null);

        mockMvc.perform(
                put("/users/{id}", user.getId())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(user)))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).findById(user.getId());
        verifyNoMoreInteractions(userService);
    }

    // ================= Delete User ===================

    @Test
    public void test_delete_user_success() throws Exception {
        User user = new User(1, "Arya Stark");

        when(userService.findById(user.getId())).thenReturn(user);
        doNothing().when(userService).delete(user.getId());

        mockMvc.perform(
                delete("/users/{id}", user.getId()))
                .andExpect(status().isOk());

        verify(userService, times(1)).findById(user.getId());
        verify(userService, times(1)).delete(user.getId());
        verifyNoMoreInteractions(userService);
    }

    @Test
    public void test_delete_user_fail_404_not_found() throws Exception {
        User user = new User(999, "user not found");

        when(userService.findById(user.getId())).thenReturn(null);

        mockMvc.perform(
                delete("/users/{id}", user.getId()))
                .andExpect(status().isNotFound());

        verify(userService, times(1)).findById(user.getId());
        verifyNoMoreInteractions(userService);
    }

    // ===================== CORS Headers ====================

    @Test
    public void test_cors_headers() throws Exception {
        mockMvc.perform(get("/users"))
                .andExpect(header().string("Access-Control-Allow-Origin", "*"))
                .andExpect(header().string("Access-Control-Allow-Methods", "POST, GET, PUT, OPTIONS, DELETE"))
                .andExpect(header().string("Access-Control-Allow-Headers", "*"))
                .andExpect(header().string("Access-Control-Max-Age", "3600"));
    }

    public static String asJsonString(final Object obj) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            return mapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

/************** output *********************

22:16:29,294 |-INFO in ch.qos.logback.classic.LoggerContext[default] - Could NOT find resource [logback.groovy]
22:16:29,294 |-INFO in ch.qos.logback.classic.LoggerContext[default] - Found resource [logback-test.xml] at [file:/C:/temp/workbench/workbench-spring/SpringRestTemplateIntegrationTest/target/test-classes/logback-test.xml]
22:16:29,327 |-INFO in ch.qos.logback.classic.joran.action.ConfigurationAction - debug attribute not set
22:16:29,332 |-INFO in ch.qos.logback.core.joran.action.AppenderAction - About to instantiate appender of type [ch.qos.logback.core.ConsoleAppender]
22:16:29,336 |-INFO in ch.qos.logback.core.joran.action.AppenderAction - Naming appender as [STDOUT]
22:16:29,361 |-WARN in ch.qos.logback.core.ConsoleAppender[STDOUT] - This appender no longer admits a layout as a sub-component, set an encoder instead.
22:16:29,361 |-WARN in ch.qos.logback.core.ConsoleAppender[STDOUT] - To ensure compatibility, wrapping your layout in LayoutWrappingEncoder.
22:16:29,361 |-WARN in ch.qos.logback.core.ConsoleAppender[STDOUT] - See also http://logback.qos.ch/codes.html#layoutInsteadOfEncoder for details
22:16:29,361 |-INFO in ch.qos.logback.classic.joran.action.LoggerAction - Setting level of logger [org.springframework] to DEBUG
22:16:29,361 |-INFO in ch.qos.logback.classic.joran.action.LoggerAction - Setting additivity of logger [org.springframework] to false
22:16:29,362 |-INFO in ch.qos.logback.core.joran.action.AppenderRefAction - Attaching appender named [STDOUT] to Logger[org.springframework]
22:16:29,362 |-INFO in ch.qos.logback.classic.joran.action.LoggerAction - Setting level of logger [com.memorynotfound] to DEBUG
22:16:29,362 |-INFO in ch.qos.logback.classic.joran.action.LoggerAction - Setting additivity of logger [com.memorynotfound] to false
22:16:29,362 |-INFO in ch.qos.logback.core.joran.action.AppenderRefAction - Attaching appender named [STDOUT] to Logger[com.memorynotfound]
22:16:29,362 |-INFO in ch.qos.logback.classic.joran.action.RootLoggerAction - Setting level of ROOT logger to DEBUG
22:16:29,362 |-INFO in ch.qos.logback.core.joran.action.AppenderRefAction - Attaching appender named [STDOUT] to Logger[ROOT]
22:16:29,362 |-INFO in ch.qos.logback.classic.joran.action.ConfigurationAction - End of configuration.
22:16:29,362 |-INFO in ch.qos.logback.classic.joran.JoranConfigurator@957e06 - Registering current configuration as safe fallback point

2017-02-02 22:16:29 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:29 [main] INFO  c.m.controller.UserController - getting user with id: 1
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $['id']
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $['username']

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - creating new user: User{id=0, username='username exists'}
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - a user with name username exists already exists

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - deleting user with id: 1

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - updating user: User{id=1, username='Arya Stark'}

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - getting user with id: 1
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - user with id 1 not found

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - getting all users
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $[0]['id']
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $[0]['username']
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $[1]['id']
2017-02-02 22:16:30 [main] DEBUG c.j.j.internal.path.CompiledPath - Evaluating path: $[1]['username']

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - deleting user with id: 999
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - Unable to delete. User with id 999 not found

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - creating new user: User{id=0, username='Arya Stark'}

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - getting all users
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - no users found

2017-02-02 22:16:30 [main] INFO  com.memorynotfound.filter.CORSFilter - Adding CORS Headers ........................
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - updating user: User{id=999, username='user not found'}
2017-02-02 22:16:30 [main] INFO  c.m.controller.UserController - User with id 999 not found

*******************************************/

