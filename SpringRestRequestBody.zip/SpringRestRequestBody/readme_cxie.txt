// readme_cxie.txt
// 1/24/2017, 2/01/2017

http://www.baeldung.com/spring-requestmapping

https://github.com/eugenp/tutorials/tree/master/

This poject demos the following:

    1. Spring MockMvc
    2. @RequestBody
    3. Use JUnit to test Spring Rest
    
 For each *Test.java, just right click --> Run As --> Junit Test
 
 All successfully!
    