package org.baeldung.client;

public interface Consts {
    int APPLICATION_PORT = 8082;
}
