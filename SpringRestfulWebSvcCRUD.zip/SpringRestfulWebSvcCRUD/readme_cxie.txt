// readme_cxie.txt
// 09/05/2016, 04/03/2017

http://www.java2blog.com/2016/04/spring-restful-web-services-crud-example.html

Step 1: mvn -Dmaven.test.skip=true clean package

Step 2: Deploy SpringRestfulWebSvcCRUD.war in Tomcat 

Step 3: Start Tomcat if it is not running

Step 4: Run RESTfullWebSvcUnitTest.java as JUnit Test

Successful !

--------------- In Eclipse -------------------

1. Right click on SpringRestfulWebSvcCRUD --> Run As --> Run on Server

2. Run RESTfullWebSvcUnitTes.java as JUnit Test

3. Use Postman to test Add/Update/Delete/Retrieve operations
