package app.test;

import static org.junit.Assert.assertNotNull;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.arpit.java2blog.bean.Country;
import org.junit.Test;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringApplicationConfiguration(classes = Application.class)
//@WebIntegrationTest
public class RESTfullWebSvcUnitTest {

	// Required to Generate JSON content from Java objects
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

	// Test RestTemplate to invoke the APIs.
	private RestTemplate restTemplate = new TestRestTemplate();

	@Test
	public void testGetAllCountriesApiInObjectArray() {

		System.out.println("\nIn testGetAllCountriesApiInObjectAray() .........");

		String uri = "http://localhost:8080/SpringRestfulWebSvcCRUD/countries";

		// Invoke the API
		Country[] countries = restTemplate.getForObject(uri, Country[].class);

		System.out.println("How many countries retrieved from server: " + countries.length);

		int ctr = 0;

		for (Country country : countries) {

			System.out.println("ctr=" + (ctr++) + ", " + country);
		}

		System.out.println("End testGetAllCountriesApiInObjectArray() .........\n");
	}

	@Test
	public void testGetAllCountriesApiInJSON() {

		System.out.println("\nIn testGetAllCountriesApiInJSON() .........");

		String uri = "http://localhost:8080/SpringRestfulWebSvcCRUD/countries";

		String result = restTemplate.getForObject(uri, String.class);

		System.out.println(result);

		System.out.println("End testGetAllCountriesApiInJSON() .........\n");
	}

	@Test
	public void testPostForObject() throws Exception {

		System.out.println("\nIn testPostForObject() .........");

		String url = "http://localhost:8080/SpringRestfulWebSvcCRUD/countries";

		RestTemplate restTemplate = new RestTemplate();

		// Building the Request body data
		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("countryName", "P.R.China");
		requestBody.put("population", 140000000 + (int) (Math.random() * 10000000));

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		// Creating http entity object with request body and headers
		HttpEntity<String> httpEntity = new HttpEntity<String>(OBJECT_MAPPER.writeValueAsString(requestBody),
				requestHeaders);

		// Invoking the API
		Country apiResponse = restTemplate.postForObject(url, httpEntity, Country.class);

		assertNotNull(apiResponse);

		System.out.println("Created country successfully  ");

		int countryID = apiResponse.getId();
		System.out.println("Country ID assigned by server side:	" + countryID);
		System.out.println("Country returned from server side:	" + apiResponse);

		System.out.println("End testCreateBookApi() .........\n");
	}

	@Test
	public void testDelete() throws Exception {

		System.out.println("\nIn testDelete() .........");

		String url = "http://localhost:8080/SpringRestfulWebSvcCRUD/country/{id}";

		RestTemplate restTemplate = new RestTemplate();

	    Map<String, Object> map = new HashMap<String, Object>();
	    map.put("id", 2);
	      
	    ResponseEntity<Country> countryEntity = restTemplate.getForEntity(url, Country.class, map);
	    System.out.println("Country from serve side:"+countryEntity.getBody());
	    System.out.println("Now going to delete it");
	    		
		//Now Invoke the API to delete the book
		restTemplate.delete(url, map);
		
		System.out.println("After delete, let us check again");
		testGetAllCountriesApiInObjectArray();
		
		System.out.println("End testDelete() .........\n");		
	}
	
	@Test
	public void testPut() throws Exception {

		System.out.println("\nIn testPut() .........");

		String url = "http://localhost:8080/SpringRestfulWebSvcCRUD/countries";

		// Now create Request body with the updated Book Data.
		Map<String, Object> requestBody = new HashMap<String, Object>();
		requestBody.put("id", "3");
		requestBody.put("countryName", "Nepal");
		requestBody.put("population", "6668888");
		
		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.setContentType(MediaType.APPLICATION_JSON);

		// Creating http entity object with request body and headers
		HttpEntity<String> httpEntity = new HttpEntity<String>(
				OBJECT_MAPPER.writeValueAsString(requestBody), requestHeaders);

		// Invoking the API
		Map<String, Object> apiResponse = (Map) restTemplate.exchange(
				url, HttpMethod.PUT,
				httpEntity, Map.class, Collections.EMPTY_MAP).getBody();

		System.out.println("Update the country successfully. Now check the countries.");
	        
		testGetAllCountriesApiInObjectArray();
		
		System.out.println("End testPut() .........\n");				
	}
}
/************ output ***********************
In testPut() .........
Update the country successfully. Now check the countries.

In testGetAllCountriesApiInObjectAray() .........
How many countries retrieved from server: 4
ctr=0, id=1,countryName=India,population=10000
ctr=1, id=3,countryName=Nepal,population=6668888
ctr=2, id=4,countryName=China,population=20000
ctr=3, id=5,countryName=P.R.China,population=143428393
End testGetAllCountriesApiInObjectArray() .........

End testPut() .........

In testGetAllCountriesApiInJSON() .........
[{"id":1,"countryName":"India","population":10000},{"id":3,"countryName":"Nepal","population":6668888},{"id":4,"countryName":"China","population":20000},{"id":5,"countryName":"P.R.China","population":143428393}]
End testGetAllCountriesApiInJSON() .........

In testGetAllCountriesApiInObjectAray() .........
How many countries retrieved from server: 4
ctr=0, id=1,countryName=India,population=10000
ctr=1, id=3,countryName=Nepal,population=6668888
ctr=2, id=4,countryName=China,population=20000
ctr=3, id=5,countryName=P.R.China,population=143428393
End testGetAllCountriesApiInObjectArray() .........

In testDelete() .........
Country from serve side:null
Now going to delete it
After delete, let us check again

In testGetAllCountriesApiInObjectAray() .........
How many countries retrieved from server: 4
ctr=0, id=1,countryName=India,population=10000
ctr=1, id=3,countryName=Nepal,population=6668888
ctr=2, id=4,countryName=China,population=20000
ctr=3, id=5,countryName=P.R.China,population=143428393
End testGetAllCountriesApiInObjectArray() .........

End testDelete() .........

In testPostForObject() .........
Created country successfully  
Country ID assigned by server side:	6
Country returned from server side:	id=6,countryName=P.R.China,population=149275856
End testCreateBookApi() .........

*******************************************/