package com.howtodoinjava.example;

//http://bethecoder.com/applications/tutorials/csv/super-csv/read-csv.html

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.supercsv.io.CsvListReader;
import org.supercsv.prefs.CsvPreference;

public class CsvListReaderDemo {

	public static void main(String[] args) throws IOException {
		/**
		 * Load CSV from classpath
		 */
		CsvListReader csvReader = new CsvListReader(
				new InputStreamReader(CsvListReaderDemo.class.getClassLoader().getResourceAsStream("test.csv")),
				CsvPreference.STANDARD_PREFERENCE);

		List<String> rowAsTokens;
		while ((rowAsTokens = csvReader.read()) != null) {
			System.out.print("Row#" + csvReader.getLineNumber() + " ");
			for (String token : rowAsTokens) {
				System.out.print(token + " ");
			}
			System.out.println();
		}
	}
}

/************ outout **************
Row#1 aaaa bbbb cccc dddd 
Row#2 one two three four  
**********************************/
