package com.howtodoinjava.example;

import java.io.FileReader;
import java.io.IOException;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.constraint.StrRegEx;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvBeanReader;
import org.supercsv.io.ICsvBeanReader;
import org.supercsv.prefs.CsvPreference;

public class ReadCSVFileExample {

	static final String CSV_FILENAME = "data.csv";

	public static void main(String[] args) throws IOException 
	{
		try(ICsvBeanReader beanReader = new CsvBeanReader(new FileReader(CSV_FILENAME), CsvPreference.STANDARD_PREFERENCE))
		{
			// the header elements are used to map the values to the bean
			final String[] headers = beanReader.getHeader(true);
			//final String[] headers = new String[]{"CustomerId","CustomerName","Country","PinCode","Email"};
			final CellProcessor[] processors = getProcessors();

			Customer customer;
			while ((customer = beanReader.read(Customer.class, headers, processors)) != null) {
				System.out.println(customer);
			}
		} 
	}

	/**
	 * Sets up the processors used for the examples.
	 */
	private static CellProcessor[] getProcessors() {
		final String emailRegex = "[a-z0-9\\._]+@[a-z0-9\\.]+";
		StrRegEx.registerMessage(emailRegex, "must be a valid email address");

		final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(new ParseInt()), // CustomerId
				new NotNull(), // CustomerName
				new NotNull(), // Country
				new Optional(new ParseLong()), // PinCode
				new StrRegEx(emailRegex) // Email
		};
		return processors;
	}
}
/****************** output *****************
 
Customer [CustomerId=10001, CustomerName=Lokesh, Country=India, PinCode=110001, Email=abc@gmail.com]
Customer [CustomerId=10002, CustomerName=John, Country=USA, PinCode=220002, Email=def@gmail.com]
Customer [CustomerId=10003, CustomerName=Blue, Country=France, PinCode=330003, Email=ghi@gmail.com]
Customer [CustomerId=10004, CustomerName=Reddy, Country=Jermany, PinCode=440004, Email=abc@gmail.com]
Customer [CustomerId=10005, CustomerName=Kumar, Country=India, PinCode=110001, Email=def@gmail.com]
Customer [CustomerId=10006, CustomerName=Paul, Country=USA, PinCode=220002, Email=ghi@gmail.com]
Customer [CustomerId=10007, CustomerName=Grimm, Country=France, PinCode=330003, Email=abc@gmail.com]
Customer [CustomerId=10008, CustomerName=WhoAmI, Country=Jermany, PinCode=440004, Email=def@gmail.com]
Customer [CustomerId=10009, CustomerName=Bharat, Country=India, PinCode=110001, Email=ghi@gmail.com]
Customer [CustomerId=10010, CustomerName=Rocky, Country=USA, PinCode=220002, Email=abc@gmail.com]
Customer [CustomerId=10011, CustomerName=Voella, Country=France, PinCode=330003, Email=def@gmail.com]
Customer [CustomerId=10012, CustomerName=Gruber, Country=Jermany, PinCode=440004, Email=ghi@gmail.com]
Customer [CustomerId=10013, CustomerName=Satty, Country=India, PinCode=110001, Email=abc@gmail.com]
Customer [CustomerId=10014, CustomerName=Bean, Country=USA, PinCode=220002, Email=def@gmail.com]
Customer [CustomerId=10015, CustomerName=Krish, Country=France, PinCode=330003, Email=ghi@gmail.com]

******************************************/

