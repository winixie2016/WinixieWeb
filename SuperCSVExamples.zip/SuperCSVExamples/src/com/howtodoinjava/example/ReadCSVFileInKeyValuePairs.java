package com.howtodoinjava.example;

import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.constraint.StrRegEx;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvMapReader;
import org.supercsv.io.ICsvMapReader;
import org.supercsv.prefs.CsvPreference;

public class ReadCSVFileInKeyValuePairs {

	static final String CSV_FILENAME = "data.csv";

	public static void main(String[] args) throws IOException 
	{
		try(ICsvMapReader listReader = new CsvMapReader(new FileReader(CSV_FILENAME), CsvPreference.STANDARD_PREFERENCE))
		{
			//First Column is header names
			final String[] headers = listReader.getHeader(true);
			
			for (String str: headers) {
				System.out.print(str + "   ");	
			}
			System.out.println();
			
			final CellProcessor[] processors = getProcessors();

			Map<String, Object> fieldsInCurrentRow;
			while ((fieldsInCurrentRow = listReader.read(headers, processors)) != null) {
				System.out.println(fieldsInCurrentRow);
				for (String key: fieldsInCurrentRow.keySet()) {
					System.out.println("key="+key+", value="+fieldsInCurrentRow.get(key));
				}					
			}
		}
	}

	/**
	 * Sets up the processors used for the examples.
	 */
	private static CellProcessor[] getProcessors() {
		final String emailRegex = "[a-z0-9\\._]+@[a-z0-9\\.]+";
		StrRegEx.registerMessage(emailRegex, "must be a valid email address");

		final CellProcessor[] processors = new CellProcessor[] { new NotNull(new ParseInt()), // CustomerId
				new NotNull(), // CustomerName
				new NotNull(), // Country
				new Optional(new ParseLong()), // PinCode
				new StrRegEx(emailRegex) // Email
		};

		return processors;
	}
}

/**************** output ********************************
 
 CustomerId   CustomerName   Country   PinCode   Email   
{Country=India, CustomerId=10001, CustomerName=Lokesh, Email=abc@gmail.com, PinCode=110001}
key=Country, value=India
key=CustomerId, value=10001
key=CustomerName, value=Lokesh
key=Email, value=abc@gmail.com
key=PinCode, value=110001
{Country=USA, CustomerId=10002, CustomerName=John, Email=def@gmail.com, PinCode=220002}
key=Country, value=USA
key=CustomerId, value=10002
key=CustomerName, value=John
key=Email, value=def@gmail.com
key=PinCode, value=220002
{Country=France, CustomerId=10003, CustomerName=Blue, Email=ghi@gmail.com, PinCode=330003}
key=Country, value=France
key=CustomerId, value=10003
key=CustomerName, value=Blue
key=Email, value=ghi@gmail.com
key=PinCode, value=330003
{Country=Jermany, CustomerId=10004, CustomerName=Reddy, Email=abc@gmail.com, PinCode=440004}
key=Country, value=Jermany
key=CustomerId, value=10004
key=CustomerName, value=Reddy
key=Email, value=abc@gmail.com
key=PinCode, value=440004
{Country=India, CustomerId=10005, CustomerName=Kumar, Email=def@gmail.com, PinCode=110001}
key=Country, value=India
key=CustomerId, value=10005
key=CustomerName, value=Kumar
key=Email, value=def@gmail.com
key=PinCode, value=110001
{Country=USA, CustomerId=10006, CustomerName=Paul, Email=ghi@gmail.com, PinCode=220002}
key=Country, value=USA
key=CustomerId, value=10006
key=CustomerName, value=Paul
key=Email, value=ghi@gmail.com
key=PinCode, value=220002
{Country=France, CustomerId=10007, CustomerName=Grimm, Email=abc@gmail.com, PinCode=330003}
key=Country, value=France
key=CustomerId, value=10007
key=CustomerName, value=Grimm
key=Email, value=abc@gmail.com
key=PinCode, value=330003
{Country=Jermany, CustomerId=10008, CustomerName=WhoAmI, Email=def@gmail.com, PinCode=440004}
key=Country, value=Jermany
key=CustomerId, value=10008
key=CustomerName, value=WhoAmI
key=Email, value=def@gmail.com
key=PinCode, value=440004
{Country=India, CustomerId=10009, CustomerName=Bharat, Email=ghi@gmail.com, PinCode=110001}
key=Country, value=India
key=CustomerId, value=10009
key=CustomerName, value=Bharat
key=Email, value=ghi@gmail.com
key=PinCode, value=110001
{Country=USA, CustomerId=10010, CustomerName=Rocky, Email=abc@gmail.com, PinCode=220002}
key=Country, value=USA
key=CustomerId, value=10010
key=CustomerName, value=Rocky
key=Email, value=abc@gmail.com
key=PinCode, value=220002
{Country=France, CustomerId=10011, CustomerName=Voella, Email=def@gmail.com, PinCode=330003}
key=Country, value=France
key=CustomerId, value=10011
key=CustomerName, value=Voella
key=Email, value=def@gmail.com
key=PinCode, value=330003
{Country=Jermany, CustomerId=10012, CustomerName=Gruber, Email=ghi@gmail.com, PinCode=440004}
key=Country, value=Jermany
key=CustomerId, value=10012
key=CustomerName, value=Gruber
key=Email, value=ghi@gmail.com
key=PinCode, value=440004
{Country=India, CustomerId=10013, CustomerName=Satty, Email=abc@gmail.com, PinCode=110001}
key=Country, value=India
key=CustomerId, value=10013
key=CustomerName, value=Satty
key=Email, value=abc@gmail.com
key=PinCode, value=110001
{Country=USA, CustomerId=10014, CustomerName=Bean, Email=def@gmail.com, PinCode=220002}
key=Country, value=USA
key=CustomerId, value=10014
key=CustomerName, value=Bean
key=Email, value=def@gmail.com
key=PinCode, value=220002
{Country=France, CustomerId=10015, CustomerName=Krish, Email=ghi@gmail.com, PinCode=330003}
key=Country, value=France
key=CustomerId, value=10015
key=CustomerName, value=Krish
key=Email, value=ghi@gmail.com
key=PinCode, value=330003

 *********************************************/
