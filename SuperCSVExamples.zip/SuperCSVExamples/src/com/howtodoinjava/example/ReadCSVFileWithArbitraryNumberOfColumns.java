package com.howtodoinjava.example;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.supercsv.cellprocessor.Optional;
import org.supercsv.cellprocessor.ParseInt;
import org.supercsv.cellprocessor.ParseLong;
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.constraint.StrRegEx;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvListReader;
import org.supercsv.io.ICsvListReader;
import org.supercsv.prefs.CsvPreference;

public class ReadCSVFileWithArbitraryNumberOfColumns {

	static final String CSV_FILENAME = "data2.csv";

	public static void main(String[] args) throws IOException 
	{
		try(ICsvListReader listReader = new CsvListReader(new FileReader(CSV_FILENAME), CsvPreference.STANDARD_PREFERENCE))
		{
			//First Column is header names- though we don't need it in runtime
			@SuppressWarnings("unused")
			final String[] headers = listReader.getHeader(true);
			final CellProcessor[] processors = getProcessors();

			List<Object> fieldsInCurrentRow;
			while ((fieldsInCurrentRow = listReader.read(processors)) != null) {
				System.out.println(String.format("rowNo=%s, customerList=%s", listReader.getRowNumber(), fieldsInCurrentRow));
			}
		} 
	}

	/**
	 * Sets up the processors used for the examples.
	 */
	private static CellProcessor[] getProcessors() {
		final String emailRegex = "[a-z0-9\\._]+@[a-z0-9\\.]+";
		StrRegEx.registerMessage(emailRegex, "must be a valid email address");

		final CellProcessor[] processors = new CellProcessor[] {
				new NotNull(new ParseInt()), // CustomerId
				new NotNull(), // CustomerName
				new NotNull(), // Country
				new Optional(new ParseLong()), // PinCode
				new StrRegEx(emailRegex) // Email
		};
		return processors;
	}
}

/**************************************** output **********************
 
rowNo=2, customerList=[10001, Lokesh, India, 110001, abc@gmail.com]
rowNo=3, customerList=[10002, John, USA, 220002, def@gmail.com]
rowNo=4, customerList=[10003, Blue, France, 330003, ghi@gmail.com]
rowNo=5, customerList=[10004, Reddy, Jermany, 440004, abc@gmail.com]
rowNo=6, customerList=[10005, Kumar, India, 110001, def@gmail.com]
rowNo=7, customerList=[10006, Paul, USA, 220002, ghi@gmail.com]
rowNo=8, customerList=[10007, Grimm, France, 330003, abc@gmail.com]
rowNo=9, customerList=[10008, WhoAmI, Jermany, 440004, def@gmail.com]
rowNo=10, customerList=[10009, Bharat, India, 110001, ghi@gmail.com]
rowNo=11, customerList=[10010, Rocky, USA, 220002, abc@gmail.com]
rowNo=12, customerList=[10011, Voella, France, 330003, def@gmail.com]
rowNo=13, customerList=[10012, Gruber, Jermany, 440004, ghi@gmail.com]
rowNo=14, customerList=[10013, Satty, India, 110001, abc@gmail.com]
rowNo=15, customerList=[10014, Bean, USA, 220002, def@gmail.com]
rowNo=16, customerList=[10015, Krish, France, 330003, ghi@gmail.com]

**********************************************************************/
